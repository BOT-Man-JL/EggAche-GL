EggAche.c
	WNDCLASSA
	"LJN_WNDCLASS"
	RegisterClassA
	#pragma
Demo.c
	#pragma
	#ifdef _DEBUG
